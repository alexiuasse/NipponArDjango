#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 12/07/2020 19:42.

from django.apps import AppConfig


class DeviceConfig(AppConfig):
    name = 'device'

#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 06/08/2020 09:31.
TITLE_VIEW_DEVICE = "Equipamentos"
TITLE_CREATE_DEVICE = "Novo Equipamento"
TITLE_EDIT_DEVICE = "Editar Equipamento"
TITLE_DEL_DEVICE = "Deletar Equipamento"
SUBTITLE_DEVICE = "Configuração de equipamentos"
HEADER_CLASS_DEVICE = "card-header-info"  # class of card header, basically just change the color

#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 14/08/2020 16:56.

TITLE_VIEW_ORDER_OF_SERVICE = "Ordem de Serviço"
TITLE_CREATE_ORDER_OF_SERVICE = "Nova Ordem de Serviço"
TITLE_EDIT_ORDER_OF_SERVICE = "Editar Ordem de Serviço"
TITLE_DEL_ORDER_OF_SERVICE = "Deletar Ordem de Serviço"
SUBTITLE_ORDER_OF_SERVICE = "Ordem de Serviços"
HEADER_CLASS_ORDER_OF_SERVICE = "card-header-success"

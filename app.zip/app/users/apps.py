#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 08/07/2020 10:18.

from django.apps import AppConfig


class UsersConfig(AppConfig):
    name = 'users'

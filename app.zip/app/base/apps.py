#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 10/07/2020 09:00.

from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = 'base'

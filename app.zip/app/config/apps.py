#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 12/07/2020 19:50.

from django.apps import AppConfig


class ConfigConfig(AppConfig):
    name = 'config'

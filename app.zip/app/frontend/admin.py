#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 10/08/2020 12:49.

from django.contrib import admin

from .models import *

admin.site.register(NotificationsMessages)

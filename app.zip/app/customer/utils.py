#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 28/07/2020 20:57.

def make_dict(obj):
    ret_dict = {}
    data_dict = obj.__dict__

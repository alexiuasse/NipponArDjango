#  Created by Alex Matos Iuasse.
#  Copyright (c) 2020.  All rights reserved.
#  Last modified 10/07/2020 08:26.

from django.apps import AppConfig


class CustomerConfig(AppConfig):
    name = 'customer'
